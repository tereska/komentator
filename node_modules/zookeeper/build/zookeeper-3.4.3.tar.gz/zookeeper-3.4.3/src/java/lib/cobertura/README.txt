Download the cobertura binary from the following location and unpack it into this directory. Run "cobertura-report" target from build.xml to generate coverage report.

http://cobertura.sourceforge.net/download.html
